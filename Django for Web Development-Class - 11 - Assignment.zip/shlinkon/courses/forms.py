from django import forms

class StudentRegistration(forms.Form):
    first_name = forms.CharField()
    last_name = forms.CharField()
    email = forms.EmailField()
    batch = forms.IntegerField()
    #phone_number = forms.IntegerField(widget=forms.HiddenInput())
    password = forms.CharField(widget=forms.PasswordInput())
    textarea = forms.CharField(widget=forms.Textarea())
    checkbox = forms.CharField(widget=forms.CheckboxInput())