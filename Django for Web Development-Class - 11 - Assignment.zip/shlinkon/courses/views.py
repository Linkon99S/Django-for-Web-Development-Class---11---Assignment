from django.shortcuts import render
from django.http import HttpResponse
from . models import Student
from . forms import StudentRegistration

# Create your views here.
def course(request):
    return HttpResponse('Welcome Shahadot Hossain Linkon in Django for web & AI')

def data_science(request):
    available_course={'fcourse':['Machine Learning', 'Deep Learning', 'Data Analysis', 'Big Data', 'Django', 'AWS']}
    return render(request, 'courses/datascience.html', available_course)

def machine_learning(request):
    return render(request, 'courses/machinelearning.html')

def deep_learning(request):
    return render(request, 'courses/deeplearning.html')

def big_data(request):
    return render(request, 'courses/bigdata.html')

def home(request):
    return render(request, 'courses/home.html')

def student_info(request):
    sdetails = Student.objects.all()
    return render(request, 'courses/student.html', {'std':sdetails})

def show_form(request):
    frm = StudentRegistration(auto_id=True,)
    #frm.order_fields(field_order=['first_name','last_name','email','batch'])
    return render(request, 'courses/forms.html', {'form':frm})

